package com.harsh.to_do_list;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    CheckBox ch1,ch2,ch3,ch4,ch5,ch6,ch7,ch8;
    AppCompatButton add_task;
    ImageView cross1,cross2,cross3,cross4,cross5,cross6,cross7,cross8;

    EditText add_task_ed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ch1 = findViewById(R.id.checkbox1);
        ch2 = findViewById(R.id.checkbox2);
        ch3 = findViewById(R.id.checkbox3);
        ch4 = findViewById(R.id.checkbox4);
        ch5 = findViewById(R.id.checkbox5);
        ch6 = findViewById(R.id.checkbox6);
        ch7 = findViewById(R.id.checkbox7);

        cross1 = findViewById(R.id.cross1);
        cross2 = findViewById(R.id.cross2);
        cross3 = findViewById(R.id.cross3);
        cross4 = findViewById(R.id.cross4);
        cross5 = findViewById(R.id.cross5);
        cross6 = findViewById(R.id.cross6);
        cross7 = findViewById(R.id.cross7);

        add_task_ed = findViewById(R.id.ed_for_task);

        add_task = findViewById(R.id.add_task);

        add_task.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ch1.setVisibility(View.VISIBLE);
                ch1.setText("");
                cross1.setVisibility(View.VISIBLE);

                String str = add_task_ed.getText().toString().trim();

                ch1.setText(str);
                add_task_ed.setText("");

                if(ch1.getVisibility() == View.VISIBLE)
                {
                    String str1 = add_task_ed.getText().toString().trim();
                    ch2.setVisibility(View.VISIBLE);
                    ch2.setText(str1);
                    cross2.setVisibility(View.VISIBLE);
                }
                else {
                    ch2.setVisibility(View.GONE);
                    cross2.setVisibility(View.GONE);
                }

                if(ch2.getVisibility() == View.VISIBLE)
                {
                    String str2 = add_task_ed.getText().toString().trim();
                    ch3.setVisibility(View.VISIBLE);
                    ch3.setText(str2);
                    cross3.setVisibility(View.VISIBLE);
                }
                else {
                    ch3.setVisibility(View.GONE);
                    cross3.setVisibility(View.GONE);
                }

                if(ch3.getVisibility() == View.VISIBLE) {
                    String str3 = add_task_ed.getText().toString().trim();
                    ch4.setVisibility(View.VISIBLE);
                    ch4.setText(str3);
                    cross4.setVisibility(View.VISIBLE);
                }
                else {
                    ch4.setVisibility(View.GONE);
                    cross4.setVisibility(View.GONE);
                }

                if(ch4.getVisibility() == View.VISIBLE) {
                    String str4 = add_task_ed.getText().toString().trim();
                    ch5.setVisibility(View.VISIBLE);
                    ch5.setText(str4);
                    cross5.setVisibility(View.VISIBLE);
                }
                else {
                    ch5.setVisibility(View.GONE);
                    cross5.setVisibility(View.GONE);
                }

                if(ch5.getVisibility() == View.VISIBLE) {
                    String str5 = add_task_ed.getText().toString().trim();
                    ch6.setVisibility(View.VISIBLE);
                    ch6.setText(str5);
                    cross6.setVisibility(View.VISIBLE);
                }
                else {
                    ch6.setVisibility(View.GONE);
                    cross6.setVisibility(View.GONE);
                }

            }
        });

    }
}